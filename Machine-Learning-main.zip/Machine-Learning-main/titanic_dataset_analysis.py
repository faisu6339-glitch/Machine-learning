import pandas as pd

dataset = pd.read_csv('D:/MCA 2024 -2026/Python ML/datasets/titanic.csv')
print(dataset.head())